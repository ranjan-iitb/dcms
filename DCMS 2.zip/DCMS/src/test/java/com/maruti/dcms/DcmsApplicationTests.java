package com.maruti.dcms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DcmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
