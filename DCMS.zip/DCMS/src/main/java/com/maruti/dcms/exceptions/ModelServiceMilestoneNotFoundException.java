package com.maruti.dcms.exceptions;

public class ModelServiceMilestoneNotFoundException extends RuntimeException {

    public ModelServiceMilestoneNotFoundException(String mssg)
    {
        super(mssg);
    }


}
