package com.maruti.dcms.repository;

import com.maruti.dcms.entity.ModelList;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModelListRepository extends JpaRepository<ModelList, String> {



}
