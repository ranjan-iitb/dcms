package com.maruti.dcms.exceptions;

public class ModelServiceActivityNotFoundException extends RuntimeException {

    public ModelServiceActivityNotFoundException(String mssg)
    {
        super(mssg);
    }
}
