package com.maruti.dcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DcmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DcmsApplication.class, args);
	}

}
