package com.maruti.dcms.exceptions;

public class IncorrectDateFormatException extends RuntimeException{

    public IncorrectDateFormatException(String mssg){
        super(mssg);
    }
}
